import * as React from 'react';

import {
  BrowserRouter as Router,
  Switch,
  IndexRoute,
  Route,
  Link
} from "react-router-dom";

export interface ICourseProps{
   
 
}

export interface ICourseState{
  
}

export default class ComponentB extends React.Component<ICourseProps, ICourseState> {

  
  

  public render(): React.ReactElement<ICourseProps> {
     return (
       
      
      <div>
            

          HI

          

     </div>

        
      
      
    );
     
  }
}