/* tslint:disable */
require("./ReactWebpartDemo.module.css");
const styles = {
  reactWebpartDemo: 'reactWebpartDemo_6265952b',
  container: 'container_6265952b',
  row: 'row_6265952b',
  column: 'column_6265952b',
  'ms-Grid': 'ms-Grid_6265952b',
  title: 'title_6265952b',
  subTitle: 'subTitle_6265952b',
  description: 'description_6265952b',
  button: 'button_6265952b',
  label: 'label_6265952b',
  'grid-container': 'grid-container_6265952b',
  colorblack: 'colorblack_6265952b',
  show: 'show_6265952b',
  hide: 'hide_6265952b',
  center: 'center_6265952b'
};

export default styles;
/* tslint:enable */