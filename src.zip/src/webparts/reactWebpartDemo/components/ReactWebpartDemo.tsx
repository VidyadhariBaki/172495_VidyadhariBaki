import * as React from 'react';
import styles from './ReactWebpartDemo.module.scss';
import { IReactWebpartDemoProps } from './IReactWebpartDemoProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {CourseField} from '../CourseField';
import {CourseList, ICourseListProps} from './CourseList';
import Component from '../components/Component'

export default class ReactWebpartDemo extends React.Component<IReactWebpartDemoProps, {}> {
private _course: CourseField[]=[
  {id:1, courseName:'HTML', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)},
  {id:2, courseName:'CSS', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)},
  {id:3, courseName:'JAVASCRIPT', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)},
  {id:4, courseName:'TYPESCRIPT', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)},
  {id:5, courseName:'C#', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)},
  {id:6, courseName:'SHAREPOINT', startDate:new Date("2019-12-29"),endDate:new Date("2019-12-29"),instructorName:'Mr.Vaidya Sagar',enrolled:(false)}
]

  public render(): React.ReactElement<IReactWebpartDemoProps> {
    return (
      <div className={ styles.reactWebpartDemo }>
        <div className={ styles.container }>
          <div className={ styles.row }>
            <div className={ styles.column }>
              <span className={ styles.title }>Welcome to SharePoint!</span>
                           
              <CourseList course={this._course}/>
              
              {/*<Component/> */}            
            </div>
          </div>
        </div>
      </div>
    );
  }

}
