import * as React from 'react';
import {CourseField} from '../CourseField';
import styles from './ReactWebpartDemo.module.scss';
import { List } from 'office-ui-fabric-react/lib/List';
import { DefaultButton } from 'office-ui-fabric-react/lib/Button';

export interface ICourseListProps{
    course: CourseField[];
}

export interface IState {
    enrolledList: CourseField[];
}

export class CourseList extends React.Component<ICourseListProps,{}, IState> {
    constructor(props) {
        super(props);
    }

    readonly state = {
        enrolledList: []
    }

    public render(): React.ReactElement<ICourseListProps>{
        return(<div>
              AVAILABLE COURSES :
            <List items={this.props.course}
            onRenderCell={this._onRenderListCell}

            ></List> <br></br>
            <div className={styles.center}>
            <button onClick={() => {
                let element = document.getElementById("enrolledcourses");
                let courses = "";
                this.state.enrolledList.forEach((course) => {
                    courses += "" + course.courseName + "<br />";
                })

                element.innerHTML = courses;

                if(element.style.display == "" || element.style.display == "none") element.style.display = "block";
                else element.style.display = "none";

            }}>ENROLLED COURSES</button><br></br>
            <div id="enrolledcourses"></div>
            </div>
            </div>
        );

    }


    private _onRenderListCell=(course: CourseField, index:number | undefined):JSX.Element =>{
        return(
        
        <div>
            <br />
            <div>
                <DefaultButton onClick={() => {
                    let element = document.getElementById("" + course.id);
                    
                    if(element.style.display == "none" || element.style.display == "") {
                        element.innerHTML = "<br><button>Start Date :</button> <br>" + course.startDate + 
                        "<br><br> <button> End Date : </button><br>" + course.endDate + 
                        "<br><br><br><button> Instructor Name:</button>" + course.instructorName + 
                        "";
                        element.style.display = "block";
                    } else element.style.display = "none";

                    }}> {course.courseName}</DefaultButton>

                    <button onClick={() => {
                        let res= this.state.enrolledList.filter((encourse) => encourse === course);
                        
                        if(res == undefined || res.length == 0) {
                            this.setState({ enrolledList: [...this.state.enrolledList, course] });
                        } else console.log("Already Enrolled!");

                        }}>ENROLL NOW</button>
                 <div id={"" + course.id}></div> 
            </div>
        </div>
        
        
        );
    }

}