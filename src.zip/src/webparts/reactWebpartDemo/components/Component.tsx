import * as React from 'react';

import {
  BrowserRouter as Router,
  Switch,
  IndexRoute,
  Route,
  Link
} from "react-router-dom";
import ComponentB from './ComponentB'

export interface ICourseProps{
   
 
}

export interface ICourseState{
  
}

export default class Component extends React.Component<ICourseProps, ICourseState> {

  
  

  public render(): React.ReactElement<ICourseProps> {
     return (
       
      
      <div>
        <Router>
            <div>
                <ul>
                    <li>
                        <Link to="/">Welcome</Link>
                        
                    </li>
                    <li>
                        <Link to="/home">Home</Link>
                    </li>
                </ul>

            </div>

          
                <Route to="/" exact component={ComponentB} />
                <Route to="/home" component={ComponentB} />


          </Router>


     </div>

        
      
      
    );
     
  }
}