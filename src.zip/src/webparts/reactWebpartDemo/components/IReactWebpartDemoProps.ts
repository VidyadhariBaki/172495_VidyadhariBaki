
export interface IReactWebpartDemoProps {
  description: string;
}
