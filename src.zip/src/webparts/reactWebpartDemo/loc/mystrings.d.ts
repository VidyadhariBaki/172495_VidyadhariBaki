declare interface IReactWebpartDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ReactWebpartDemoWebPartStrings' {
  const strings: IReactWebpartDemoWebPartStrings;
  export = strings;
}
