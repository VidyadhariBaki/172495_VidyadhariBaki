export interface CourseField{
    id: number;
    courseName: string;
    startDate: Date;
    endDate : Date;
    instructorName: string;
    enrolled: boolean
  }