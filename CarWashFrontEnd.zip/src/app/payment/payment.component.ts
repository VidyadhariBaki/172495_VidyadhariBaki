import { Component, OnInit } from '@angular/core';
import { UserService } from '../UserService';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {PaymentPojo} from './PaymentPojo';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  submitted:any=true
 
  constructor(private fb: FormBuilder,private route:Router,private userService: UserService) { }
  payForm:FormGroup
  paypojo:PaymentPojo=new PaymentPojo();
  data:any
  check=false
  
  ngOnInit() 
  {
    this.payForm = this.fb.group({
     // nameoncard:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
      nameoncard:['', [Validators.required ]],
      creditcardnumber:['', [Validators.required ]],
      expmonth:['', [Validators.required ]],
      expyear:['', [Validators.required ]],
      cvv:['', [Validators.required ]],
     
   });
  }

  onPayment(){
    this.submitted=false
    
    console.log(this.paypojo)
    this.paypojo.username=this.userService.value.username;
      this.userService.payment(this.paypojo)
      .subscribe((data) => this.data=data, error => console.log(error));
     // this.route.navigateByUrl("login")
      this.onCheck()
}
onCheck()
{
  this.check=true;
}

}


