export class PaymentPojo {
    nameoncard:string
    creditcardnumber:string
    expmonth:string
    expyear:string
    cvv:string
    username:string
 }

 