import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
  })
export class UserService
{
  result:any;
  islogin=false;
  bookpojo: any;
  vehicleNum: any;

    private baseUrl = 'http://localhost:8888/signin/api';
    private signup='http://localhost:4567/signup/api';
    private adminUrl='http://localhost:1111/admin/api';
    private addvehicle = 'http://localhost:1212/addvehicle/api';
    private bookwash = 'http://localhost:9010/bookwashservice/api';
    private payment1 = 'http://localhost:7777/payment/api';
    private getDetailsUrl='http://localhost:1212/api';
    private getUsersUrl='http://localhost:4567/signup/api';
    constructor(private http: HttpClient) { }
value:any;
    getUser(id: number): Observable<Object> {
        return this.http.get(`${this.baseUrl}/${id}`);
      }

      createUser(register: Object): Observable<Object> {
  
        console.log(register)
        
        return this.http.post(`${this.signup}` + `/customer/signup`, register);
       
       }
       validateUser(login: Object): Observable<Object> {
        return this.http.post(`${this.baseUrl}` + `/customer/validate`, login);
      }

      validateAdmin(login: Object): Observable<Object> {
       return this.http.post(`${this.adminUrl}` + `/admin/validate`, login);
     }

      userDetails(userName:string)
      {
        console.log("value")
        console.log(userName)
        return this.value=userName;
      }

      vehicleNo(vehicleNumber:string)
      {
        console.log("vehicleNum")
       
        return this.vehicleNum=vehicleNumber;
      }
      addVehicle(addvpojo: Object): Observable<Object> {
        //throw new Error("Method not implemented.");
        console.log(addvpojo)
        console.log(`${this.addvehicle}` + `/vehicleadd`)
        return this.http.post(`${this.addvehicle}` + `/vehicleadd`, addvpojo);
      }

      bookservice(bookpojo: Object): Observable<Object>
   {
     console.log(bookpojo);
    return this.http.post(`${this.bookwash}` + `/bookWash`, bookpojo);
  }

  payment(paypojo: Object): Observable<Object>
 {
  console.log(paypojo)
     return this.http.post(`${this.payment1}` + `/payment1`, paypojo);
  }

  getDetails():Observable<Object> {
   console.log("inresponse")
    
    return this.http.get(`${this.getDetailsUrl}`+'/user/all');
  }

  getUserDetails(): Observable<Object> {
  
   
    console.log("inresponse")
    
    return this.http.get(`${this.getUsersUrl}`+'/customer');
   
   
   }
      }
