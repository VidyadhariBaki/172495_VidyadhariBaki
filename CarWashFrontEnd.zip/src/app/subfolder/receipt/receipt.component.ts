import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/UserService';
import { ReceiptPojo } from './receiptPojo';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css']
})
export class ReceiptComponent implements OnInit {

  constructor(private route:Router,private userService:UserService) { }
  rcpPojo: ReceiptPojo = new ReceiptPojo();

  ngOnInit(): void {
  this.rcpPojo.vehiclenumber=this.userService.vehicleNum;
  }

  readValue(key)
 {
   return localStorage.getItem(key);
 }
}
