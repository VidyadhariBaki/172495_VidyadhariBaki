
export class ReceiptPojo
{
    packageType:string;
    washType:String;
    vehiclenumber:string;
}