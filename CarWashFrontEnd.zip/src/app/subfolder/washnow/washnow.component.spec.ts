import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WashnowComponent } from './washnow.component';

describe('WashnowComponent', () => {
  let component: WashnowComponent;
  let fixture: ComponentFixture<WashnowComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WashnowComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WashnowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
