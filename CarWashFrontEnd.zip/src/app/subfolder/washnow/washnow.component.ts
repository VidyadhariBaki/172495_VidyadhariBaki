import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/UserService';

@Component({
  selector: 'app-washnow',
  templateUrl: './washnow.component.html',
  styleUrls: ['./washnow.component.css']
})
export class WashnowComponent implements OnInit {
  result:any;
  constructor(private route:Router,private userService:UserService) { }

  ngOnInit() {
    this. getDetails();
    
  }
  getDetails()
  {
  this.userService.getDetails().subscribe((response) =>{ 
    console.log("in response")
    console.log(response)
  console.log("hiiiiii");
    this.result=response;
  });
 }

 buyNow()
 {
  this.route.navigateByUrl("home");
 }

 readValue(key)
 {
   return localStorage.getItem(key);
 }

}
