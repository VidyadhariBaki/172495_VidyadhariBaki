import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BookingcarwashComponent } from './bookingcarwash.component';

describe('BookingcarwashComponent', () => {
  let component: BookingcarwashComponent;
  let fixture: ComponentFixture<BookingcarwashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookingcarwashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookingcarwashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
