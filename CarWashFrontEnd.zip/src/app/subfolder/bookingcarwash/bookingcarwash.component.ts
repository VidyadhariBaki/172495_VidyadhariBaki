import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BookwashPojo } from 'src/app/bookingcarwashpojo'
import { UserService } from 'src/app/UserService';


@Component({
  selector: 'app-bookingcarwash',
  templateUrl: './bookingcarwash.component.html',
  styleUrls: ['./bookingcarwash.component.css']
}) 
export class BookingcarwashComponent implements OnInit {

  bookpojo: BookwashPojo = new BookwashPojo();
  submitted = false;
  constructor(private fb: FormBuilder,private route:Router,private userService: UserService) { }
  bookForm:FormGroup
  //login:LoginPojo=new LoginPojo();
  //Register:RegisterPojo=new RegisterPojo();
  ngOnInit() {
    
    this.bookForm=this.fb.group(
      {
        //email:['',[ Validators.required,Validators.pattern('^[a-zA-Z0-9_.+-]+@gmail.com+$')] ],
        location:['',[ Validators.required] ],
        date:['',[Validators.required]],
        packageType:['',[Validators.required]],
        washer:['',[Validators.required]],
        washType:['',[Validators.required]]
      })  }

  save() {
    console.log("in save")
    console.log(this.bookpojo)
    this.bookpojo.username=this.userService.value.username;
    this.bookpojo.vehiclenumber=this.userService.vehicleNum.vehiclenumber;
    this.userService.bookservice(this.bookpojo)
      .subscribe(data => console.log(data), error => console.log(error));
    this.bookpojo= new BookwashPojo();
   
  }

  onAdd() {
    this.submitted = true;
    console.log("onadd")
    this.save();
    this.route.navigateByUrl("payment")

  }
 
}

