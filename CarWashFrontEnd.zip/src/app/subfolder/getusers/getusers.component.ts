import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/UserService';


@Component({
  selector: 'app-getusers',
  templateUrl: './getusers.component.html',
  styleUrls: ['./getusers.component.css']
})
export class GetusersComponent implements OnInit {
  result:any;
  constructor(private userservice:UserService) { }
 
  ngOnInit() {
    this.getAllUsers();
  }

  getAllUsers()
  {
       this.userservice.getUserDetails().subscribe((response) =>{ 
        console.log("in response")
        console.log(response)
        this.result=response;
      });
    }
}
