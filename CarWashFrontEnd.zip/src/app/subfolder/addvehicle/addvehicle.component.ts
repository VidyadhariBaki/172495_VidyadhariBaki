import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { AddvehiclePojo } from 'src/app/AddvehiclePojo';
import { UserService } from 'src/app/UserService';


@Component({
  selector: 'app-addvehicle',
  templateUrl: './addvehicle.component.html',
  styleUrls: ['./addvehicle.component.css']
})
export class AddvehicleComponent implements OnInit {

   // Vehiclenumber:string
  // Brand:string
  // VehicleModel:string
 
  addvpojo: AddvehiclePojo = new AddvehiclePojo();
  submitted=false;
  constructor(private fb: FormBuilder,private route:Router,private userService: UserService) { }
  vehicleForm:FormGroup
  //login:LoginPojo=new LoginPojo();
  //Register:RegisterPojo=new RegisterPojo();
  ngOnInit() {
    
    this.vehicleForm=this.fb.group(
      {
        
         vehiclenumber:[' ',[ Validators.required] ],
         brand:[' ',[Validators.required]],
         vehicleModel:[' ',[Validators.required]]
        
      
      })  }
value:any;
  save() {
    console.log("in save")
    console.log(this.addvpojo)
    console.log(this.userService.value.username)
    this.addvpojo.username=this.userService.value.username;
    console.log(this.addvpojo)
    this.userService.addVehicle(this.addvpojo)
      .subscribe(data => 
        {
          this.value=data;
    //  console.log("inresponse vale")
    //  console.log(this.value)
    localStorage.setItem('vnumber',data['vehiclenumber']);
      this.userService.vehicleNo(this.value);
console.log(data), error => console.log(error)});
    // this.addvpojo= new AddvehiclePojo();
    this.route.navigateByUrl("washnow");
  }

  
  onAdd() {
    this.submitted = true;
    console.log("onadd")
    this.save();
   // this.route.navigateByUrl("login")

  }
 }



