import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { CarouselModule } from 'ngx-bootstrap/carousel';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AddvehicleComponent } from './subfolder/addvehicle/addvehicle.component';
import { BookingcarwashComponent } from './subfolder/bookingcarwash/bookingcarwash.component';
import { PaymentComponent } from './payment/payment.component';
import { ReceiptComponent } from './subfolder/receipt/receipt.component';
import { WasherloginComponent } from './subfolder/washerlogin/washerlogin.component';
import { MyordersComponent } from './subfolder/myorders/myorders.component';
import { WashnowComponent } from './subfolder/washnow/washnow.component';
import { GetusersComponent } from './subfolder/getusers/getusers.component';
import { DeleteuserComponent } from './subfolder/deleteuser/deleteuser.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    SignUpComponent,
    AdminloginComponent,
    AddvehicleComponent,
    BookingcarwashComponent,
    PaymentComponent,
    ReceiptComponent,
    WasherloginComponent,
    MyordersComponent,
    WashnowComponent,
    GetusersComponent,
    DeleteuserComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,



    RouterModule.forRoot( [
      

      {
        path: '',
        redirectTo:'/home',
        pathMatch:'full'
      }, 
      {
        path: 'home', 
        component:HomeComponent 
      },
      
      { 
        path: 'login',
        component:LoginComponent 
      },
        { 
        path: 'sign-up',
        component:SignUpComponent 
      },
      {
        path:'adminlogin',
        component:AdminloginComponent
      },
      {
        path:'addvehicle',
        component:AddvehicleComponent
      },
      {
        path:'bookingCarWash',
        component:BookingcarwashComponent
      },
      {
        path:'payment',
        component:PaymentComponent
      },
      {
        path:'washer',
        component: WasherloginComponent
      }
      ,
      {
        path:'washnow',
        component:WashnowComponent
      },
      {
        path:'receipt',
        component:ReceiptComponent
      },
      {
        path:'getusers',
        component:GetusersComponent
      }
     ]),

     CarouselModule.forRoot(),

  
    
    BsDropdownModule.forRoot()
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

