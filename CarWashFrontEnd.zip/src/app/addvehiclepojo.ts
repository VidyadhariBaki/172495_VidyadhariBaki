export class AddvehiclePojo {
vehiclenumber:string
color:string
vehicleModel:string
username:string
}


