export class LoginAccount
{
    username:string;
   /*  localStorage.getItem('uname'); */
    password:string;
    
}



