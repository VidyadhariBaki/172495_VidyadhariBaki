export class BookwashPojo{
    location:string;
    date:string;
    username:string;
    packageType:string;
    washType:String
    washer:string
    vehiclenumber:string
}
